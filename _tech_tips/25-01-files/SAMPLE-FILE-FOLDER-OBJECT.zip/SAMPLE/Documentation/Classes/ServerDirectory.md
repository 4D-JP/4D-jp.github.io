<!-- Type your summary here -->
## Description

サーバー側のフォルダー／ファイルを使いやすくするためのクラス

## Example

```4d
$SharedFolderObject:=cs.ServerDirectory.new()
Form.LISTBOX:=$SharedFolderObject$.files()
```
