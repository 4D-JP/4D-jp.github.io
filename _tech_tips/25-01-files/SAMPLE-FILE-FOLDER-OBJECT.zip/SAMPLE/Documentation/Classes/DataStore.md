<!-- Type your summary here -->
## Description

サーバー側で必ず動作するクラス（４Ｄ標準のクラス）

### Note

このクラスはメソッドから直接利用しない。