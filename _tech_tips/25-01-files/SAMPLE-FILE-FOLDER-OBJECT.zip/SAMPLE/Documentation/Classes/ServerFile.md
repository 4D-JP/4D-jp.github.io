## Description

クライント側でサーバー側にあるファイルを扱うためのクラス

## Example

```4d
$filePath:="/Volumes/Support/▲テクサポ/__共有フォルダー__/" //注意:サーバー側のファイルパス
$file:=cs.ServerFile.new($filePath)
```

## Function

### new

渡されたパスでServerFileオブジェクトのインスタンスを生成。

| 引数 | 型 | in/out | 概要 |
| --- | --- | --- | --- |
| path | Text | in -> | サーバー側のファイルパス |
| file | ServerFileオブジェクト | <- out | ServerFileオブジェクト |

> [!IMPORTANT]
> 
> 渡すパスは、サーバー側のファイルパスである点に注意


### getContent

| 引数 | 型 | in/out | 概要 |
| --- | --- | --- | --- |
| content | Blob | <- out | 取り出したファイルの内容 |
