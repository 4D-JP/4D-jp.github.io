<!-- Type your summary here -->
## Description

サーバー側のフォルダーをフォルダーオブジェクトとして取り出すメソッド

> [!WARNING]
> 
> この方法は、お勧めできない方法の例です


## Example

```4d
Form.LISTBOX:=on_server_side
```
